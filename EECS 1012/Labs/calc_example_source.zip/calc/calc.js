var display = "0";
var register;
var operation;
function number(s) {
  "use strict";
  var x = document.getElementById("display");
  if(display == "0") {
    display = s;
  } else if((s != '.')||(display.indexOf(".") < 0)) {
    display = display + s;
  }
  x.innerHTML = display;
}

function op(s) {
  register = Number(display);
  display = "0";
  document.getElementById("display").innerHTML = display;
  operation = s;
}

function clr() {
  display = "0";
  operation = "";
  register = 0;
  document.getElementById("display").innerHTML = display;
}

function equals() {
  if(operation == "+") {
    display = register + Number(display);
  } else if(operation == '-') {
    display = register - Number(display);
  } else if(operation == '*') {
    display = register * Number(display);
  } else if(operation == '/') {
    display = register / Number(display);
    if(!isFinite(display)) {
      display = 0.0;
    }
  }
  document.getElementById("display").innerHTML = display;
  operation = "";
}

window.onload = function() {
  display = "0";
  var x = document.getElementById("display");
  x.innerHTML = display
}
