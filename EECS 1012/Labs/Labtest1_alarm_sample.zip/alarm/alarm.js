/*
 * alarm.js -
 */

 var sumn = 0;
 var suma = 0;
 var threshold;
 var alarmOn = false;
 var alarmTriggered = false;
 var button;
function init() {
  window.addEventListener('devicemotion', motion);
  button = document.getElementById("button");
}

function pressed() {
  if(alarmOn) {
    alarmOn = false;
    suma = 0;
    sumn = 0;
    threshold = 0;
    alarmTriggered = false;
    button.innerHTML ="ENABLE ALARM";
  } else { // arm the alarm
    alarmOn = true;
    threshold = 1.2 * suma / sumn;
    alarmTriggered = false;
    button.innerHTML = "DISABLE ALARM";
  }
}


function motion(e) {
  var x = e.accelerationIncludingGravity.x;
  var y = e.accelerationIncludingGravity.y;
  var z = e.accelerationIncludingGravity.z;
  var acc = x * x + y * y + z * z;

  var p  = document.getElementById("debug");
  p.innerHTML = "alarm on " + alarmOn + "<br>";
  if(alarmTriggered) {
    p.innerHTML += "alarm triggered<br>";
    button.bgcolor = "green";
  } else {
    if(alarmOn) {
      p.innerHTML += "threshold " + threshold + " acc " + acc + "<br>";
      alarmTriggered = acc > threshold;
    } else {
      suma = suma + acc;
      sumn = sumn + 1;
    }
  }
}

window.onload=init;
