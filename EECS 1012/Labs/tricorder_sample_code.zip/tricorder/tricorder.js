function randomizer() {
  for(var i=0;i<3;i++) {
    changeColor("light" + (i+1));
  }
  changeVideo("random" + Math.floor(Math.random() * 4) + ".gif");
}

function changeVideo(file) {
  var x = document.getElementById("video1");
  x.src = file;
}

function changeColor(id) {
  var x = document.getElementById(id);
  if(Math.random() > 0.5) {
    x.style.backgroundColor = "white";
  } else {
    x.style.backgroundColor = "black";
  }
}

function init() {
  window.setInterval(randomizer, 500);
}

window.onload=init;
