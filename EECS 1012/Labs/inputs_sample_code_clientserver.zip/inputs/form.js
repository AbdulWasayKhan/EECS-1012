function ok()
{
  var x = document.getElementById("output");
  var q = "Text is |" + document.getElementById("text").value + "|<br>";
  q += "Radio1 is " + document.getElementById("radio1").checked + "<br>";
  q += "Radio2 is " + document.getElementById("radio2").checked + "<br>";
  q += "Radio3 is " + document.getElementById("radio3").checked + "<br>";
  q += "Radio4 is " + document.getElementById("radio4").checked + "<br>";
  q += "Radio5 is " + document.getElementById("radio5").checked + "<br>";
  q += "Checked1 is " + document.getElementById("check1").checked + "<br>";
  q += "Checked2 is " + document.getElementById("check2").checked + "<br>";
  q += "Checked3 is " + document.getElementById("check3").checked + "<br>";
  var dropdown = document.getElementById("select1");
  var index = dropdown.selectedIndex;
  var value = dropdown.options[index].value;
  q += "Select1 is " + value + "<br>";
  dropdown = document.getElementById("select2");
  index = dropdown.selectedIndex;
  value = dropdown.options[index].value;
  q += "Select2 is " + value + "<br>";
  x.innerHTML = q + "<br>";
}

function reset()
{
  document.getElementById("text").value = "";
  document.getElementById("radio1").checked = true;
  document.getElementById("radio4").checked = true;
  document.getElementById("check1").checked = false;
  document.getElementById("check2").checked = false;
  document.getElementById("check3").checked = false;
}
