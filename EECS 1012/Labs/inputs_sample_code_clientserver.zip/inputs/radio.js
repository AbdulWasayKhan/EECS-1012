function clicked()
{
  var input1 = document.getElementById("radio1").checked;
  var input2 = document.getElementById("radio2").checked;
  var input3 = document.getElementById("radio3").checked;
  alert("value " + input1 + " " + input2 + " " + input3);
}
