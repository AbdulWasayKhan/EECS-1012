function clicked() 
{
  var input = document.getElementById("mytextarea");
  alert("You entered " + input.value);
}
