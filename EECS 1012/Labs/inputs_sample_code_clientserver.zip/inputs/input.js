function clicked() 
{
  var input = document.getElementById("input");
  alert("You entered " + input.value);
}
