function clicked() 
{
  var input = document.getElementById("myrange");
  alert("You entered " + input.value);
}
