function OnChange()
{
  var dropdown = document.getElementById("select1");
  var index = dropdown.selectedIndex;
  var value = dropdown.options[index].value;
  alert("You selected " + value);
}
