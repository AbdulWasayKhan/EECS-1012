function clicked()
{
  var input1 = document.getElementById("check1").checked;
  var input2 = document.getElementById("check2").checked;
  var input3 = document.getElementById("check3").checked;
  alert("value " + input1 + " " + input2 + " " + input3);
}
