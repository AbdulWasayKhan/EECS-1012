var EMPTY = ' ';
var FULL = 'X';

var globalWorld;
var running = false;
var timer;

function initWorld() {
  "use strict";
  var setup = [
      "          ",
      "          ",
      " X        ",
      "  X       ",
      "XXX       ",
      "          ",
      "          ",
      "          ",
      "          ",
      "          "
  ];
  var w = setup[0].length;
  var h = setup.length;
  var world = createEmptyWorld(w, h);
  for(var i=0;i<h;i++) {
    for(var j=0;j<w;j++) {
      if(setup[i].charAt(j) == ' ') {
        world[i][j] = EMPTY;
      } else {
        world[i][j] = FULL;
      }
    }
  }
  return world;
}



function drawCanvas(id, world) {
  "use strict";
  var canvas = document.getElementById("canvas");
  var ctx = canvas.getContext("2d");
  var w = world[0].length;
  var h = world.length;
  var cellw = Math.floor(canvas.width / w);
  var cellh = Math.floor(canvas.height / h);

  for(var i=0;i<h;i++) {
    for(var j=0;j<w;j++) {
      if(world[i][j] == EMPTY) {
        ctx.fillStyle = "#000000";
      } else {
        ctx.fillStyle = "#ff0000";
      }
      ctx.fillRect(j*cellw, i*cellh, cellw, cellh);
      ctx.strokeStyle = "#ffffff";
      ctx.strokeRect(j*cellw, i*cellh, cellw, cellh);
    }
  }
}

function createEmptyWorld(w, h) {
  "use strict";
  var world = new Array(h);
  for(var i=0;i<h;i++) {
    world[i] = new Array(w);
    for(var j=0;j<w;j++) {
      world[i][j] = EMPTY;
    }
  }
  return world;
}

function countNeighbours(world, w, h, i, j) {
  "use strict";
  var count = 0;
  for(var oi= -1; oi <= 1; oi++) {
    for(var oj= -1; oj <= 1; oj++) {
      if((oi!=0)||(oj!=0)) {
        var ni = i + oi;
        var nj = j + oj;
        if((ni >= 0)&&(nj >=0)&&(ni<h)&&(nj<w)&&(world[ni][nj]==FULL)) {
          count++;
        }
      }
    }
  }
  return count;
}

function applyRules(world) {
  "use strict";
  var w = world[0].length;
  var h = world.length;
  var newWorld = createEmptyWorld(w, h);
  for(var i=0;i<h;i++) {
    for(var j=0;j<w;j++) {
      var count = countNeighbours(world, w, h, i, j);
      if(world[i][j] == FULL) {
        if((count < 2)||(count > 3)) {
          newWorld[i][j] = EMPTY;
        } else {
          newWorld[i][j] = FULL;
        }
      } else {
        if(count == 3) {
          newWorld[i][j] =  FULL;
        } else {
          newWorld[i][j] = EMPTY;
        }
      }
    }
  }
  return newWorld;
}



function init() {
  "use strict";
  globalWorld = initWorld();
  drawCanvas('canvas', globalWorld);
}

function oneStep() {
  "use strict";
  if(!running) {
    var tmp = applyRules(globalWorld);
    globalWorld = tmp;
    drawCanvas('canvas', globalWorld);
  }
}

function step() {
  "use strict";
  var tmp = applyRules(globalWorld);
  globalWorld = tmp;
  drawCanvas('canvas', globalWorld);
  timer = setTimeout(step, 500);
}


function go() {
  "use strict";
  var button = document.getElementById("go");
  if(running) {
    running = false;
    button.innerHTML = "Run";
    clearTimeout(timer);
  } else {
    running = true;
    button.innerHTML = "Stop";
    timer = setTimeout(step, 500);
  }
}
    
    

function randomize() {
  "use strict";
  globalWorld = initWorld();
  for(var i=0;i<globalWorld.length;i++) {
    for(var j=0;j<globalWorld[0].length;j++) {
      if(Math.random() > 0.5) {
        globalWorld[i][j] = FULL;
      } else {
        globalWorld[i][j] = EMPTY;
      }
    }
  }
  drawCanvas('canvas', globalWorld);
}

window.onload=init;
